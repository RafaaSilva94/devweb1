import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import Title from './../components/Title/index';

function Detalhes() {
  const { livro } = useParams();
  const [isqn, setLivro ] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetch(`https://my-json-server.typicode.com/marycamila184/moviedetails/moviedetails/${isqn}`)
      .then(response => response.json())
      .then(data => {
        //setlivro(data);
        setIsLoading(false);
      })
      .catch(error => console.error(error));
  }, [isqn]);

  if (isLoading) {
    return <p className='text-center'>Carregando...</p>;
  }

  if (!livro) {
    return <p className='text-center'>Não foi possível encontrar os detalhes do filme.</p>;
  }

  return (
    <div className="container text-center">
      <Title title={livro.titulo} text="Informações do livro clicado:" />
      <div className="row">
        <div className="col">
          <img
            src={livro.poster}
            alt={livro.titulo}
            className="poster"
          />
        </div>
      </div>
      <hr />
    </div>
  );
}

export default Detalhes;