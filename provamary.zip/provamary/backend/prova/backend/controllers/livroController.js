const livroModel = require('../models/livroModel');
const auth = require('../auth/auth');


class LivroController {
    async salvar(req, res) {
        const livro = req.body;
        const max = await livroModel.findOne({}).sort({ codigo: -1 });
        livro.codigo = max == null ? 1 : max.codigo + 1;

        if (await livroModel.findOne({ 'ISQN': livro.isqn })) {
            res.status(400).send({ error: 'Livro já cadastrado!' });
        }

        const resultado = await livroModel.create(livro);
        auth.incluirToken(resultado);
        res.status(201).json(resultado);
    }

    async listar(req, res) {
        const resultado = await livroModel.find({});
        res.status(200).json(resultado);
    }

    async buscarPorIsqn(req, res) {
        const isqn = req.params.isqn;
        const resultado = await livroModel.findOne({ 'ISQN': isqn });
        res.status(200).json(resultado);
    }

    async atualizar(req, res) {
        const codigo = req.params.codigo;
        const _id = String((await livroModel.findOne({ 'codigo': codigo }))._id);

        const cliente = req.body;

        await livroModel.findByIdAndUpdate(String(_id), cliente);
        res.status(200).send();
    }

    async excluir(req, res) {
        const isqn = req.params.isqn;
        const _id = String((await livroModel.findOne({ 'ISQN': isqn }))._id);

        await livroModel.findByIdAndRemove(String(_id));
        res.status(200).send();
    }
}

module.exports = new LivroController();