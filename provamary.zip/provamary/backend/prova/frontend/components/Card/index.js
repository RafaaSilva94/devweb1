import "./Card.css";

const card = [{
  "livro": "Pai Rico Pai Pobre",
  "tema": "Finanças",
  "ano": "1997"
},
{
  "livro": "O Segredo",
  "tema": "Auto-ajuda",
  "ano": "2008"
},
{
  "livro": "O Senhor dos Anéis",
  "tema": "Fantasia",
  "ano": "1954"
}
]

export default function Card() {
  return (
    <div className="container text-center">
      <div className="row">
        {card.map((card, i) => (
          <div className="col" key={i.toString()}>
            <div className="card">
              <div className="card-body">
                <h3 className="card-title">{card.livro}</h3>
                <p>{card.tema}</p>
                <p className="card-text">{card.ano}</p>
                <a
                  href={`/detalhes/${card.livro}`}
                >
                  <div className="btn btn-primary">
                    Adquirir
                  </div>
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}