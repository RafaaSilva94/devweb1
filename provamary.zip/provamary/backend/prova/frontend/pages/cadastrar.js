import React, { useState } from 'react';
import api from '../../services/api';

export default function Cadastrar() {
    const [livro, setLivro] = useState('');
    const [isbn, setIsbn] = useState('');
    const [titulo, setTitulo] = useState('');
    const [autor, setAutor] = useState('');
    const [ano, setAno] = useState('');
    const [tema, setTema] = useState('');
    const [alugado, setAlugado] = useState('');


    /*function handleLivroChange(event) {
        setLivro(event.target.value);
    }   
    
    function handleIsbnChange(event) {
        setIsbn(event.target.value);
    }

    function handleTituloChange(event) {
        setTitulo(event.target.value);
    }

    function handleAutorChange(event) {
        setAutor(event.target.value);
    }

    function handleAnoChange(event) {
        setAno(event.target.value);
    }

    function handleTemaChange(event) {
        setTema(event.target.value);
    }

    function handleAlugadoChange(event) {
        setAlugado(event.target.value);
    }*/


    function handleSubmit(event) {
        event.preventDefault();
        // enviar dados de cadastro para o servidor aqui
        //console.log(`Entidade Livro: ${livro}, ISBN: ${isbn}, Título: ${titulo}, Autor: ${autor}, Ano: ${ano}, Tema: ${tema}, Alugado: ${alugado},`);
        
        const bodyParam = {
            livro: livro,
            isbn: isbn,
            titulo: titulo,
            autor: autor,
            ano: ano,
            tema: tema,
            alugado: alugado
        }

        api.post('/clientes', bodyParam)
        .then((response) => {
            console.log(response.data)
            alert(" O livro " + response.data.codigo + " foi cadastrado com sucesso!")
        })
        .catch((err) => {
            console.error(err)
            alert(" Ocorreu um erro! Veja no console ..")
        })
        .finally(() => {
            setLivro("")
            setIsbn("")
            setTitulo("")
            setAutor("")
            setAno("")
            setTema("")
            setAlugado("")
        })
    }

    return (
        <div className="form-custom">
            <form onSubmit={handleSubmit}>
                <label>
                    Entidade livro:
                    <input type="text" className="form-control" value={livro} onChange={(e) => { setLivro(e.target.value) }} />
                </label>
                <br />
                <label>
                    ISBN:
                    <input type="number" value={isbn} onChange={(e) => { setIsbn(e.target.value) }} />
                </label>
                <label>
                    Título:
                    <input type="text" value={titulo} onChange={(e) => { setTitulo(e.target.value) }} />
                </label>
                <label>
                    Autor:
                    <input type="text" value={autor} onChange={(e) => { setAutor(e.target.value) }} />
                </label>
                <label>
                    Ano:
                    <input type="number" value={ano} onChange={(e) => { setAno(e.target.value) }} />
                </label>
                <label>
                    Tema:
                    <input type="text" value={tema} onChange={(e) => { setTema(e.target.value) }} />
                </label>
                <label>
                    Alugado:
                    <input type="boolean" value={alugado} onChange={(e) => { setAlugado(e.target.value) }} />
                </label>
                <br />
                <button type="submit">Cadastrar</button>
            </form>
        </div>
    );
}
